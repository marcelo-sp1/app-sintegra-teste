<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        
    }

    public function indexAction()
    {
        
    } 
    
    public function postAction()
    {        
       $values = $this->getRequest()->getParams();               
       $cnpj = $values['cnpj'];
       if($values['acao'] == 'listar'){           
            print_r(file_get_contents("http://local.wszendprojec/SintegraService/listar/cnpj/".$cnpj."/login/admin/pass/s1nt3gr4"));
	    exit;          
       }else{            
            print_r(file_get_contents("http://local.wszendprojec/SintegraService/buscar/cnpj/".$cnpj."/login/admin/pass/s1nt3gr4"));
            exit;
       }
    }  

}

